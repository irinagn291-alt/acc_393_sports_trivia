import SwiftUI

struct Duel10x2:View {
 let ids:[String];let play:([String])->Void
 @Environment(\.locale) private var locale
 @State private var code="SportsTrivia-"+String(UUID().uuidString.prefix(8))
 private var words:[String] {let all:[String:[String]]=["en":["Challenge code","Play this challenge","Share challenge"],"de":["Duellcode","Dieses Duell spielen","Duell teilen"],"es":["Código de duelo","Jugar este duelo","Compartir duelo"],"fr":["Code du défi","Jouer ce défi","Partager le défi"],"pt":["Código do duelo","Jogar este duelo","Compartilhar duelo"],"it":["Codice sfida","Gioca la sfida","Condividi sfida"],"ro":["Codul duelului","Joacă acest duel","Distribuie duelul"],"ru":["Код дуэли","Начать дуэль","Поделиться дуэлью"],"hu":["Kihíváskód","Kihívás indítása","Kihívás megosztása"]];return all[locale.language.languageCode?.identifier ?? "en"] ?? all["en"]!}
 private var seed:String?{let s=code.trimmingCharacters(in:.whitespacesAndNewlines);guard s.hasPrefix("SportsTrivia-"),s.count=="SportsTrivia-".count+8,s.suffix(8).allSatisfy({$0.isHexDigit}) else{return nil};return s.uppercased()}
 private func order(_ id:String,_ seed:String)->UInt64 {var n:UInt64=14695981039346656037;for b in (seed+"|"+id).utf8{n=(n ^ UInt64(b)) &* 1099511628211};return n}
 var body:some View {VStack(alignment:.leading,spacing:14){
  TextField(words[0],text:$code).textFieldStyle(.roundedBorder).autocorrectionDisabled().textInputAutocapitalization(.never)
  ShareLink(item:code.trimmingCharacters(in:.whitespacesAndNewlines)){Label(words[2],systemImage:"square.and.arrow.up")}.disabled(seed==nil)
  Button(words[1]){guard let seed else{return};let sorted=Set(ids).sorted{let a=order($0,seed),b=order($1,seed);return a==b ? $0<$1:a<b};play(Array(sorted.prefix(10)))}.buttonStyle(.borderedProminent).disabled(seed==nil || Set(ids).count<10)
 }}
}
